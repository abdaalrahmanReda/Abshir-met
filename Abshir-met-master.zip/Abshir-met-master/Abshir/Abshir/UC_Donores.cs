﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abshir
{
    public partial class UC_Donores : UserControl
    {
        public UC_Donores()
        {
            InitializeComponent();
        }

        private void UC_Donores_Load(object sender, EventArgs e)
        {

        }
    }
}
